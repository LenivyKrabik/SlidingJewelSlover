import pyautogui as pag
import time
from Solver import *
import cv2
import sys
from playsound import playsound
try:
    Letters=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P']
    i1x2="1x2.png"
    i1x3="1x3.png"
    i2x1="2x1.png"
    i3x1="3x1.png"

    b1x2=[]
    b1x3=[]
    b2x1=[]
    b3x1=[]

    AllBlocks=[]

    Time=0.5
    rPos=0
    Blur=0.94
    Attempts=4

    #1240 335
    #1640 730


    def Detect99():
        global i1x2, i1x3, i2x1, i3x1, b1x2, b1x3, b2x1, b3x1, Letters, rPos, Blur,Attempts

        grayscale=False
        
        LetterCount=0
        grid='......\n......\n......\n......\n......\n......'
        grid=list(grid)

        #Main
        answer = pag.locateOnScreen("Main.png", confidence=Blur,minSearchTime=Attempts)
        print(answer,'answer')
        answer=list(answer)
        x=(answer[0]-1240)//66
        y=(answer[1]-335)//66
        if x<0:
                x=0
        rPos=x
        grid[x+y*7]='r'
        grid[(x+1)+y*7]='r'
        
        #1x2
        answer = pag.locateAllOnScreen(i1x2, confidence=Blur,grayscale=grayscale)
        for oi in answer:
            oi=tuple(oi)
            x=(oi[0]-1240)//66
            y=(oi[1]-335)//66
            if x<0:
                x=0
            if y<0:
                y=0
            if (x,y) not in b1x2:
                b1x2.append((x,y))
        for x,y in b1x2:
            print(x,y,'1x2')
            Letr=Letters[LetterCount]
            LetterCount+=1
            grid[x+y*7]=Letr
            grid[x+(y+1)*7]=Letr
            AllBlocks.append([x,y,1,0])
        #1x3
        answer = pag.locateAllOnScreen(i1x3, confidence=Blur,grayscale=grayscale)    
        for oi in answer:
            oi=tuple(oi)
            x=(oi[0]-1240)//66
            y=(oi[1]-335)//66
            if x<0:
                x=0
            if y<0:
                y=0
            if (x,y) not in b1x3:
                b1x3.append((x,y))
        for x,y in b1x3:
            print(x,y, '1x3')
            Letr=Letters[LetterCount]
            LetterCount+=1
            grid[x+y*7]=Letr
            grid[x+(y+1)*7]=Letr
            grid[x+(y+2)*7]=Letr
            AllBlocks.append([x,y,3,0])
        #2x1
        answer = pag.locateAllOnScreen(i2x1, confidence=Blur,grayscale=grayscale)    
        for oi in answer:
            oi=tuple(oi)
            x=(oi[0]-1240)//66
            y=(oi[1]-335)//66
            if x<0:
                x=0
            if y<0:
                y=0
            if (x,y) not in b2x1:
                b2x1.append((x,y))
        for x,y in b2x1:
            print(x,y,'2x1')
            Letr=Letters[LetterCount]
            LetterCount+=1
            grid[x+y*7]=Letr
            grid[(x+1)+y*7]=Letr
            AllBlocks.append([x,y,2,0])
        #3x1
        answer = pag.locateAllOnScreen(i3x1, confidence=Blur,grayscale=grayscale)    
        for oi in answer:
            oi=tuple(oi)
            x=(oi[0]-1240)//66
            y=(oi[1]-335)//66
            if x<0:
                x=0
            if y<0:
                y=0
            if (x,y) not in b3x1:
                b3x1.append((x,y))
        for x,y in b3x1:
            print(x,y,'3x1')
            Letr=Letters[LetterCount]
            LetterCount+=1
            grid[x+y*7]=Letr
            grid[(x+1)+y*7]=Letr
            grid[(x+2)+y*7]=Letr
            AllBlocks.append([x,y,4,0])
            
        print(grid)
        return ''.join(grid)

    while True:
        grid=Detect99()
        
        
        #grid = '''
        #        .AAAB.
        #        ...DB.
        #        rr.DC.
        #        G.FDC.
        #        G.F.EE
        #        ..F...
        #    '''
        #grid = '.AAAB.\n...DB.\nrr.DC.\nG.FDC.\nG.F.EE\n..F...'
        print(grid)
        solver = Solver()
        solver.load_data(grid)
        print('Loaded data')
        solver.format_data(solver.cars)
        print('Looking for solution.. (may take several secods)')
        moves = solver.solve()
        ToDo = solver.format_steps(solver.cars, moves)
        print(ToDo)

        ToDo= ToDo.split('; ')
        ToDo[0]=ToDo[0].replace('\n\nSOLUTION\n','')
        ToDo[len(ToDo)-1]='r right'

        print(AllBlocks)

        pag.moveTo(1450,850)
        pag.click()
        time.sleep(0.1)

        #pag.moveTo(1240,240)
        #pag.click()
        #time.sleep(0.2)
        pag.moveTo(1306+rPos*66,500)
        pag.click()
        time.sleep(0.2)
        for x in ToDo:
            x=x.split()
            Name=x[0]
            Quest=x[1]
            if Quest=='right'or Quest=='down':
                Direction=1
            else:
                Direction=-1
            print(Name)
            if Name!='r':
                Name = Letters.index(Name)
                if AllBlocks[Name][2]%2==0:
                    pag.moveTo((1270+AllBlocks[Name][0]*66+AllBlocks[Name][3]*66),(360+AllBlocks[Name][1]*66))
                    pag.dragRel(66*Direction,0,Time)
                    AllBlocks[Name][3]+=Direction
                    #time.sleep(0.1)
                else:
                    pag.moveTo((1270+AllBlocks[Name][0]*66),(360+AllBlocks[Name][1]*66+AllBlocks[Name][3]*66))
                    pag.dragRel(0,66*Direction,Time)
                    AllBlocks[Name][3]+=Direction
                    #time.sleep(0.1)
            else:
                pag.moveTo(1306+rPos*66,500)
                pag.dragRel(66*Direction,0,Time)
                rPos+=1*Direction
                #time.sleep(0.1)
            if bool(pag.locateOnScreen("Next.png", confidence=Blur)):
                break

        pag.locateOnScreen("Next.png", confidence=Blur,minSearchTime=Attempts)
        pag.moveTo(1550,750)
        time.sleep(0.2)
        pag.click()
        b1x2=[]
        b1x3=[]
        b2x1=[]
        b3x1=[]

        AllBlocks=[]    
except:
    playsound('Error.mp3')
