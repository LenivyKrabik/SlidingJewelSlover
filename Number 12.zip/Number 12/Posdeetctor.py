import pyautogui as pg
while True:
    print(pg.position())
